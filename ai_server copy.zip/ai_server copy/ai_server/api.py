from flask import Flask, request

app = Flask(__name__)

@app.get("/api/1")
def hello_world():
    name = request.args.get('name')
    return f"<p>Hello, {name}! i am api1</p>"

@app.route("/api/2")
def hello_api2():
    return "<p>Hello, World! i am api2</p>"

