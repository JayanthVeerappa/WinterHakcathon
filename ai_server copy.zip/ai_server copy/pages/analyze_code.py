import streamlit as st
from openai import OpenAI
from streamlit_ace import st_ace
client = OpenAI()



def analyze_code(code):
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        stream=True,
        messages=[{"role": "user", "content": code}
            ,{"role": "system",
                       "content": "You help give comments about the persons code and help them fix it by trying to make them understand. DO not give them the code, but make them try to understand it. Add comments wherever you can, and highlight code that is weak/needs to change. "}],
    )
    for chunk in response:
        if chunk.choices[0].delta.content is not None:
            yield chunk.choices[0].delta.content
with st.form("my_form"):
    input = st_ace(
    placeholder="Write or paste your code here...",
    language="python",  # Set the language for syntax highlighting
    theme="monokai",  # You can choose different themes
    height=300,
    key="code_editor",
)
    # Every form must have a submit button.
    submitted = st.form_submit_button("Submit")

    if submitted:
        response = analyze_code(input)
        st.write_stream(response)




